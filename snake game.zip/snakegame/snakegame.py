import pygame
import time
import random

snake_speed = 15

# Akna suurus
window_x = 640
window_y = 420

# värvide määratlemine
black = pygame.Color(0, 0, 0)
white = pygame.Color(255, 255, 255)
red = pygame.Color(255, 0, 0)
green = pygame.Color(0, 255, 0)
blue = pygame.Color(0, 0, 255)
yellow = pygame.Color(255, 255, 0)
# Pygame'i initsialiseerimine
pygame.init()



# Mänguakna initsialiseerimine
pygame.display.set_caption('Snake game')
game_window = pygame.display.set_mode((window_x, window_y))

# FPS (kaadrite sekundis) kontroller
fps = pygame.time.Clock()

# mao vaikimisi positsiooni määratlemine
snake_position = [100, 50]

#Taustaheli
pygame.mixer.music.load('snakegame.mp3')
pygame.mixer.music.play(0)

# mao keha esimese 4 ploki määratlemine
snake_body = [[100, 50],
              [90, 50],
              [80, 50],
              [70, 50]
              ]
# puuvilja positsioon
fruit_position = [random.randrange(1, (window_x // 10)) * 10,
                  random.randrange(1, (window_y // 10)) * 10]

fruit_spawn = True

# mao vaikimisi suuna määramine paremale
direction = 'RIGHT'
change_to = direction

# algne skoor
score = 0

# Taimer ajaga piiratud režiimi jaoks
start_time = 0
time_limit = 10  # sekundid

# skoori kuvamise funktsioon
def show_score(choice, color, font, size):
    score_font = pygame.font.SysFont(font, size)
    score_surface = score_font.render('Score : ' + str(score), True, color)
    score_rect = score_surface.get_rect()
    game_window.blit(score_surface, score_rect)

# Taimeri kuvamise funktsioon
def show_timer(color, font, size):
    global start_time
    time_elapsed = time.time() - start_time
    time_font = pygame.font.SysFont(font, size)
    timer_surface = time_font.render('Time Left : ' + str(round(time_limit - time_elapsed, 1)), True, color)
    timer_rect = timer_surface.get_rect()
    timer_rect.midtop = (window_x / 2, 15)
    game_window.blit(timer_surface, timer_rect)

# mängu lõppemise funktsioon
def game_over():
    my_font = pygame.font.SysFont('times new roman', 50)
    game_over_surface = my_font.render(
        'Your Score is : ' + str(score), True, red)
    game_over_rect = game_over_surface.get_rect()
    game_over_rect.midtop = (window_x / 2, window_y / 4)
    game_window.blit(game_over_surface, game_over_rect)
    pygame.display.flip()
    time.sleep(2)
    play_again_or_exit()

# Uuesti mängimise või väljumise valiku funktsioon
def play_again_or_exit():
    while True:
        game_window.fill(black)
        my_font = pygame.font.SysFont('times new roman', 50)
        title_surface = my_font.render('Game Over', True, red)
        title_rect = title_surface.get_rect()
        title_rect.midtop = (window_x / 2, window_y / 4)
        game_window.blit(title_surface, title_rect)

        play_font = pygame.font.SysFont('times new roman', 35)
        play_again_surface = play_font.render('Press 1 to Play Again', True, green)
        play_again_rect = play_again_surface.get_rect()
        play_again_rect.midtop = (window_x / 2, window_y / 2)
        game_window.blit(play_again_surface, play_again_rect)

        exit_surface = play_font.render('Press 2 to Exit', True, blue)
        exit_rect = exit_surface.get_rect()
        exit_rect.midtop = (window_x / 2, window_y / 2 + 50)
        game_window.blit(exit_surface, exit_rect)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    menu()
                if event.key == pygame.K_2:
                    pygame.quit()
                    quit()

# Põhifunktsioon
def main_game(timed_mode=False):
    global direction, change_to, score, snake_position, snake_body, fruit_position, fruit_spawn, start_time
    direction = 'RIGHT'
    change_to = direction
    score = 0
    snake_position = [100, 50]
    snake_body = [[100, 50],
                  [90, 50],
                  [80, 50],
                  [70, 50]]
    fruit_position = [random.randrange(1, (window_x // 10)) * 10,
                      random.randrange(1, (window_y // 10)) * 10]
    fruit_spawn = True

    if timed_mode:
        start_time = time.time()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    change_to = 'UP'
                if event.key == pygame.K_DOWN:
                    change_to = 'DOWN'
                if event.key == pygame.K_LEFT:
                    change_to = 'LEFT'
                if event.key == pygame.K_RIGHT:
                    change_to = 'RIGHT'

        if change_to == 'UP' and direction != 'DOWN':
            direction = 'UP'
        if change_to == 'DOWN' and direction != 'UP':
            direction = 'DOWN'
        if change_to == 'LEFT' and direction != 'RIGHT':
            direction = 'LEFT'
        if change_to == 'RIGHT' and direction != 'LEFT':
            direction = 'RIGHT'

        if direction == 'UP':
            snake_position[1] -= 10
        if direction == 'DOWN':
            snake_position[1] += 10
        if direction == 'LEFT':
            snake_position[0] -= 10
        if direction == 'RIGHT':
            snake_position[0] += 10

        snake_body.insert(0, list(snake_position))
        if snake_position[0] == fruit_position[0] and snake_position[1] == fruit_position[1]:
            score += 10
            fruit_spawn = False
            if timed_mode:
                start_time = time.time()
        else:
            snake_body.pop()

        if not fruit_spawn:
            fruit_position = [random.randrange(1, (window_x // 10)) * 10,
                              random.randrange(1, (window_y // 10)) * 10]

        fruit_spawn = True
        game_window.fill(black)

        for pos in snake_body:
            pygame.draw.rect(game_window, green,
                             pygame.Rect(pos[0], pos[1], 10, 10))
        pygame.draw.rect(game_window, white, pygame.Rect(
            fruit_position[0], fruit_position[1], 10, 10))

        if snake_position[0] < 0 or snake_position[0] > window_x - 10:
            game_over()
        if snake_position[1] < 0 or snake_position[1] > window_y - 10:
            game_over()

        for block in snake_body[1:]:
            if snake_position[0] == block[0] and snake_position[1] == block[1]:
                game_over()

        show_score(1, white, 'times new roman', 20)
        if timed_mode:
            show_timer(white, 'times new roman', 20)
            if time.time() - start_time > time_limit:
                game_over()

        pygame.display.update()
        fps.tick(snake_speed)



# Menüü funktsioon
def menu():
    while True:
        game_window.fill(black)
        my_font = pygame.font.SysFont('times new roman', 50)
        title_surface = my_font.render('Snake Game', True, white)
        title_rect = title_surface.get_rect()
        title_rect.midtop = (window_x / 2, window_y / 4)
        game_window.blit(title_surface, title_rect)

        play_font = pygame.font.SysFont('times new roman', 35)
        play_surface = play_font.render('Press 1 for Classic Mode', True, green)
        play_rect = play_surface.get_rect()
        play_rect.midtop = (window_x / 2, window_y / 2)
        game_window.blit(play_surface, play_rect)

        timed_surface = play_font.render('Press 2 for Timed Mode', True, blue)
        timed_rect = timed_surface.get_rect()
        timed_rect.midtop = (window_x / 2, window_y / 2 + 50)
        game_window.blit(timed_surface, timed_rect)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    main_game(timed_mode=False)
                if event.key == pygame.K_2:
                    main_game(timed_mode=True)

menu()
