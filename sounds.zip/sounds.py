import pygame
import sys
pygame.init()

pygame.mixer.music.load('sound.mp3')
pygame.mixer.music.play(0)